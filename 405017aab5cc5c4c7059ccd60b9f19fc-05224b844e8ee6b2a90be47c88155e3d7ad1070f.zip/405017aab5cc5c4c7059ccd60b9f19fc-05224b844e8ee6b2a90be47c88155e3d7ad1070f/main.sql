-- Add an assignment with NULL due_date
INSERT INTO assignments (course_id, title, status)
VALUES ('COMP1238', 'Assignment with no date', 'Not Started');

SELECT * FROM assignments
LIMIT 10;

SELECT count(*) FROM courses;

SELECT min(due_date) FROM assignments;

SELECT *
FROM  courses
WHERE course_name LIKE 'Intro%';

SELECT sqlite_version();

SELECT upper('ABCxyz');

SELECT length('abcde');

SELECT 7*5;

SELECT concat('ABC', '-', 'xyz');

SELECT date();

SELECT strftime('%Y', due_date) AS Year, *
FROM assignments;

-- SUBSTRING(string, start, length)
SELECT DISTINCT SUBSTRING(course_id, 1, 4)
FROM courses;

-- Count how many courses there are with each prefix like 'MATH' and 'COMP'
SELECT SUBSTRING(course_id, 1, 4) AS prefix, count(*)
FROM courses
GROUP BY prefix;

SELECT *
FROM  assignments
WHERE status != 'Completed'
ORDER BY due_date;

-- Use this query as a reference for the next step
SELECT course_id, title, status, due_date
FROM assignments
WHERE status != 'Completed'
  AND course_id LIKE 'COMM%'
  AND due_date < '2024-12-31'
ORDER BY due_date;-- auto-generated definition
-- No source text available

-- Concat course name & semester = course_semester
SELECT CONCAT(course_name, ' - ', semester) AS course_semester
FROM courses;

-- lab times on friday
SELECT course_id, course_name, lab_time
FROM courses
         JOIN lab_time ON courses.course_id = lab_time.course_id
WHERE lab_time.day_of_week = 'Friday';

-- due today
SELECT *
FROM assignments
WHERE due_date > CURRENT_DATE;

-- count the number of assignments for each status
SELECT status, COUNT (*) AS assignment_count
FROM assignments
GROUP BY status;

-- longst course name
SELECT course_id, courses.course_name
FROM courses
ORDER BY LENGTH(course_name) = (
    SELECT MAX(LENGTH(course_name))
    FROM courses
);

-- uppercase course name
SELECT UPPER(course_name) AS course_name_upper
FROM courses;

-- due in sepetember
SELECT assignments.title
FROM assignments
WHERE due_date LIKE '%-09-%';

-- missing due dates
SELECT *
FROM assignments
WHERE due_date IS NULL;

